ClearMesh CLI

Install:
  mkdir -p "$HOME/.local/bin"
  cp clearmesh "$HOME/.local/bin/clearmesh"
  chmod +x "$HOME/.local/bin/clearmesh"

Quick start:
  clearmesh config set-api https://api.clearmesh.net
