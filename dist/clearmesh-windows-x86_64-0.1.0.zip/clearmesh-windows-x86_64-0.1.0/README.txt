ClearMesh CLI for Windows

Install:
1. Copy clearmesh.exe somewhere permanent.
2. Add that folder to PATH.

Quick start:
  clearmesh config set-api https://api.clearmesh.net
